package komeiji.back.websocket.persistence;

public class MessageRecord {
}
