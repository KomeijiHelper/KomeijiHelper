package komeiji.back.websocket.protocol;


public abstract class BinaryFrameTProtocol<T> implements WebSocketFrameProtocol<T> {

}
