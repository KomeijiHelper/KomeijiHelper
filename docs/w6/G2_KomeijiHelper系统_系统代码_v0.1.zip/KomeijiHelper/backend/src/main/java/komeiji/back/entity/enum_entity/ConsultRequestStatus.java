package komeiji.back.entity.enum_entity;

public enum ConsultRequestStatus {
    WAITING,
    ACCEPTED,
    CANCELED,
    REJECTED
}
