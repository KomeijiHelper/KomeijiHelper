<script setup>

</script>

<template>
  <div>
    <h1>Home</h1>
  </div>
</template>

<style scoped>
/* 这里可以添加样式 */
</style>
