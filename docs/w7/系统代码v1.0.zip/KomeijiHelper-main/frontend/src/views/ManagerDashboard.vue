<script setup>

import UserTable from "@/components/UserTable.vue";
</script>

<template>
  <user-table />
</template>

<style scoped>

</style>