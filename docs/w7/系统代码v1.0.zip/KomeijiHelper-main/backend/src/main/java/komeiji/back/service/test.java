package komeiji.back.service;

public interface test {
}
