package komeiji.back.websocket.persistence;

import komeiji.back.websocket.message.Message;

// TODO:
public class ConversationManager {

    public void addMessageRecord(Message msg) {
//        Conversation conversation;
//        MessageRecord  record;
//        conversation.addRecord(record);
    }

    public void persistenceConversation(String CID) {

    }


}
