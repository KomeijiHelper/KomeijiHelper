package komeiji.back.dto;

import lombok.Data;

@Data
public class ConsultantRequestDTO {
    private String consultantId;
    private String userId;
} 